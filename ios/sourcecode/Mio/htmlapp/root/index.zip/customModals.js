// js/customModals.js

function toggleModal(modalId, show) {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    modal.style.display = show ? 'flex' : 'none';
    document.body.style.overflow = show ? 'hidden' : '';
}

export function showAlert(message, title = 'Alerta', options = {}) {
    return new Promise(resolve => {
        const modal = document.getElementById('alertModal'); // <-- Objetivo principal
        const titleEl = document.getElementById('alertTitle');
        const messageEl = document.getElementById('alertMessage');
        const okButton = document.getElementById('alertOkButton');
        
        if (!modal || !titleEl || !messageEl || !okButton) {
            console.error('Elementos del modal de alerta no encontrados.');
            alert(message); // Fallback
            return resolve();
        }

        // Limpiar clases promocionales anteriores del contenedor principal
        modal.className = 'modal'; 

        // Aplicar nueva clase al contenedor principal si existe
        if (options.className) {
            modal.classList.add(options.className);
        }

        titleEl.textContent = title;
        messageEl.innerHTML = message.replace(/\n/g, '<br>');

        const closeHandler = () => {
            toggleModal('alertModal', false);
            // Limpiar la clase del contenedor principal al cerrar
            if (options.className) {
                modal.classList.remove(options.className);
            }
            newOkButton.removeEventListener('click', closeHandler);
            modal.querySelector('.modal-backdrop').removeEventListener('click', closeHandler);
            modal.querySelector('.close').removeEventListener('click', closeHandler);
            resolve();
        };
        
        const newOkButton = okButton.cloneNode(true);
        okButton.parentNode.replaceChild(newOkButton, okButton);

        newOkButton.addEventListener('click', closeHandler);
        modal.querySelector('.modal-backdrop').addEventListener('click', closeHandler);
        modal.querySelector('.close').addEventListener('click', closeHandler);

        toggleModal('alertModal', true);
        newOkButton.focus();
    });
}

export function showConfirm(message, title = 'Confirmación') {
    return new Promise(resolve => {
        const modal = document.getElementById('confirmModal');
        const titleEl = document.getElementById('confirmTitle');
        const messageEl = document.getElementById('confirmMessage');
        let yesButton = document.getElementById('confirmYes');
        let noButton = document.getElementById('confirmNo');

        if (!modal || !titleEl || !messageEl || !yesButton || !noButton) {
            console.error('Elementos del modal de confirmación no encontrados.');
            return resolve(confirm(message)); // Fallback
        }

        titleEl.textContent = title;
        messageEl.textContent = message;

        const cleanupAndResolve = (value) => {
            toggleModal('confirmModal', false);
            yesButton.removeEventListener('click', yesHandler);
            noButton.removeEventListener('click', noHandler);
            resolve(value);
        };

        const yesHandler = () => cleanupAndResolve(true);
        const noHandler = () => cleanupAndResolve(false);

        let newYesButton = yesButton.cloneNode(true);
        yesButton.parentNode.replaceChild(newYesButton, yesButton);
        yesButton = newYesButton;

        let newNoButton = noButton.cloneNode(true);
        noButton.parentNode.replaceChild(newNoButton, noButton);
        noButton = newNoButton;

        yesButton.addEventListener('click', yesHandler);
        noButton.addEventListener('click', noHandler);
        modal.querySelector('.modal-backdrop').addEventListener('click', noHandler, { once: true });
        modal.querySelector('.close').addEventListener('click', noHandler, { once: true });
        
        toggleModal('confirmModal', true);
        yesButton.focus();
    });
}

export function showPrompt(message, title = 'Entrada Requerida') {
    return new Promise(resolve => {
        const modal = document.getElementById('promptModal');
        const titleEl = document.getElementById('promptTitle');
        const messageEl = document.getElementById('promptMessage');
        const inputEl = document.getElementById('promptInput');
        const formEl = document.getElementById('promptForm');
        let cancelButton = document.getElementById('promptCancel');

        if (!modal || !titleEl || !messageEl || !inputEl || !formEl) {
            console.error('Elementos del modal de prompt no encontrados.');
            return resolve(prompt(message)); // Fallback
        }

        titleEl.textContent = title;
        messageEl.textContent = message;
        inputEl.value = '';

        const cleanupAndResolve = (value) => {
            toggleModal('promptModal', false);
            formEl.removeEventListener('submit', handleSubmit);
            cancelButton.removeEventListener('click', handleCancel);
            resolve(value);
        };

        const handleSubmit = (e) => {
            e.preventDefault();
            cleanupAndResolve(inputEl.value);
        };

        const handleCancel = () => {
            cleanupAndResolve(null);
        };

        let newCancelButton = cancelButton.cloneNode(true);
        cancelButton.parentNode.replaceChild(newCancelButton, cancelButton);
        cancelButton = newCancelButton;
        
        formEl.addEventListener('submit', handleSubmit, { once: true });
        cancelButton.addEventListener('click', handleCancel, { once: true });
        modal.querySelector('.modal-backdrop').addEventListener('click', handleCancel, { once: true });
        modal.querySelector('.close').addEventListener('click', handleCancel, { once: true });

        toggleModal('promptModal', true);
        inputEl.focus();
    });
}