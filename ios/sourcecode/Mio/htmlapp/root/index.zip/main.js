// js/main.js

import StateManager from './state.js';
import { ApiClient } from './api.js';
import * as UI from './ui.js';
import { initializeCalculators, handleBillCounterActions } from './calculators.js';
import { getAllHistoricalData, getFilteredHistoricalData, generateUUID } from './utils.js';
import { showAlert, showConfirm, showPrompt } from './customModals.js';

console.log("main.js: Módulo cargado.");

const APP_VERSION = "10.21";

const Session = {
    businessName: null, password: null, isAdmin: false,
    currentDate: new Date().toISOString().split('T')[0],
    save() { localStorage.setItem('ipv_session', JSON.stringify({ businessName: this.businessName, password: this.password })); },
    load() {
        const saved = localStorage.getItem('ipv_session');
        if (saved) {
            try {
                const sessionData = JSON.parse(saved);
                if (typeof sessionData.businessName === 'string' && sessionData.businessName.length > 0) {
                    this.businessName = sessionData.businessName;
                    this.password = sessionData.password;
                    return true;
                }
            } catch (e) {
                this.clear();
            }
        }
        return false;
    },
    clear() { this.businessName = null; this.password = null; this.isAdmin = false; localStorage.removeItem('ipv_session'); localStorage.removeItem('ipv_last_selected_date'); }
};

let pizzaDataLoader;

const PROMOTIONAL_MODALS = [
    { 
        title: "¡A meterle con todo!", 
        className: "promo-modal-gold-rush", 
        message: "¡Gente! Erick dice que cada pizza 'Doña Lucía' que se queda fría es un crimen. Hoy vamos a forrarnos, así que ¡sáquenle brillo a los borsillo de los clientes! <b>¡Que hoy se bebe!</b>" 
    },
    { 
        title: "¡Modo Turbo Activado!", 
        className: "promo-modal-cyber-neon", 
        message: "Okey, equipo, la orden de Erick es simple: que no quede ni una pizza para mañana. Piensen rápido, vendan más rápido. <i>¡A romperla, que para eso estamos!</i>" 
    },
    { 
        title: "¡Hoy es el Show!", 
        className: "promo-modal-velvet-lounge", 
        message: "Escuchen, Erick dice que 'Doña Lucía' es el escenario y ustedes son los artistas. ¡Que cada cliente se vaya pensando que vio el mejor show de su vida! <b>¡Luces, cámara... y a vender!</b>" 
    },
    { 
        title: "¡Hoy la suerte está de nuestro lado!", 
        className: "promo-modal-galaxy-dream", 
        message: "Erick consultó su horóscopo y dice que hoy es día de billete. La gente viene con hambre y con ganas de gastar. ¡No los hagamos esperar! <b>¡A aprovechar la buena vibra!</b>" 
    },
    { 
        title: "¡A lo que vinimos!", 
        className: "promo-modal-emerald-envy", 
        message: "Mensaje de Erick: hoy jugamos a ganar. Cada venta es un golazo. 'Doña Lucía' tiene la calidad, ustedes pongan la magia. <b>¡Que los otros se mueran de la envidia!</b>" 
    },
    { 
        title: "¡Que no se enfríe nada!", 
        className: "promo-modal-arctic-ice", 
        message: "¡Alerta, equipo! Dice Erick que el único frío que acepta es el de las bebidas. ¡Hay que mover ese inventario ya! <b>¡Vamos a darle calor a esas ventas!</b>" 
    },
    { 
        title: "¡La tienda está que arde!", 
        className: "promo-modal-fire-and-fury", 
        message: "Erick mandó a subirle la temperatura a esto. ¡Hoy vendemos con todo el power! Que la gente sienta el calorcito de las pizzas 'Doña Lucía' desde que entra. <b>¡A encender la calle!</b>" 
    },
    { 
        title: "¡Viene una oleada de gente!", 
        className: "promo-modal-ocean-depths", 
        message: "¡Prepárense! Erick dice que se viene una ola de clientes. ¡Todos a sus puestos! 'Doña Lucía' es un barco a prueba de todo, ¡demostrémoslo! <b>¡Que nadie se quede sin su pizza!</b>" 
    },
    { 
        title: "¡Hoy mandamos nosotros!", 
        className: "promo-modal-royal-purple", 
        message: "Orden del mero mero, Erick: hoy tratamos a cada cliente como un rey, para que pague como tal. Las pizzas 'Doña Lucía' son de lujo. <b>¡A darle con categoría!</b>" 
    },
    { 
        title: "¡A vaciar el sistema!", 
        className: "promo-modal-monochrome-matrix", 
        message: "Erick dice que hay un bug en el sistema: ¡demasiado inventario! Su misión es simple: dejar los estantes en cero. <b>Hoy no hay excusas, solo ventas. ¡A darle!</b>" 
    },
{ 
        title: "Nivel de Ventas: ¡ÉPICO!", 
        className: "promo-modal-pixel-power", 
        message: "¡Atención, jugadores! Erick ha cargado un nuevo desafío: ¡conseguir el HIGH SCORE de ventas! Cada pizza 'Doña Lucía' es un power-up. ¡Que no quede ni un enemigo... ni un cliente con hambre! <b>¡A JUGAR!</b>" 
    },
    { 
        title: "Una Obra Maestra del Sabor", 
        className: "promo-modal-art-deco", 
        message: "Erick presenta la colección del día. Cada pizza 'Doña Lucía' es una pieza de arte exclusiva. Se espera de ustedes una presentación impecable y ventas dignas de una galería. <i>El buen gusto se paga, señores.</i>" 
    },
    { 
        title: "¡EXTRA! ¡EXTRA!", 
        className: "promo-modal-vintage-news", 
        message: "ÚLTIMA HORA: ¡Erick declara que las pizzas 'Doña Lucía' son la noticia del día! Su misión: asegurarse de que esta noticia esté en boca de todos. <b>¡Que las ventas hagan historia!</b>" 
    },
    { 
        title: "¡Super-Vendedores al Rescate!", 
        className: "promo-modal-comic-blast", 
        message: "¡Santa Salchicha, equipo! Una ola de hambre amenaza la ciudad. Erick nos ha dado el poder de 'Doña Lucía' para combatirla. ¡Cada venta es un golpe certero contra el apetito! <b>¡BAM! ¡ZAS! ¡A la caja!</b>" 
    },
    { 
        title: "La Máquina de Ganancias", 
        className: "promo-modal-steampunk-gear", 
        message: "Ingenieros del sabor, ¡atención! El Gran Inventor Erick ha calibrado la maquinaria de 'Doña Lucía' para una producción máxima. Aceiten sus engranajes y pongan la máquina de ventas a toda marcha. <b>¡A toda máquina!</b>" 
    },
    { 
        title: "El Arte de Vender", 
        className: "promo-modal-zen-minimal", 
        message: "Hoy, la directiva de Erick es simple: menos charla, autoriza a mas putería, más acción. La perfección en 'Doña Lucía' habla por sí sola. Su trabajo es guiar al cliente hacia la iluminación... Nuestra caja. <i>Enfoque y claridad.</i>" 
    },
    { 
        title: "Dueños de la Calle", 
        className: "promo-modal-street-grunge", 
        message: "Escuchen, banda. Erick quiere que hoy 'Doña Lucía' domine el territorio de las pizzas. Somos los mejores en Cumanayagua y nadie nos va a quitar la corona. Vendan y demuéstrenle a erick. <b>¡Esta calle es nuestra!</b>" 
    },
    { 
        title: "Estreno de Taquilla", 
        className: "promo-modal-hollywood-premiere", 
        message: "¡Silencio en el set! Erick anuncia el gran estreno del día: 'El Sabor Insuperable', protagonizada por las pizzas 'Doña Lucía'. Ustedes son el elenco estrella. ¡Esperamos un éxito de taquilla! <b>¡Luces, pizza, acción!</b>" 
    },
    { 
        title: "MISIÓN: CAJA LLENA", 
        className: "promo-modal-top-secret", 
        message: "Agentes, han sido activados. Su objetivo, según el Agente en Jefe Erick: infiltrar el mercado, persuadir a los objetivos y extraer la mayor cantidad de capital. La pizza 'Doña Lucía' es su coartada. <b>Este mensaje se autodestruirá... cuando se cumpla la meta.</b>" 
    },
    { 
        title: "¡Operación Paraíso!", 
        className: "promo-modal-tiki-fiesta", 
        message: "¡Aloha, equipo! Erick ha decretado que hoy la pizzería 'Doña Lucía' es una isla de sabor. Su misión es simple: que cada cliente se sienta de vacaciones y gaste como si no hubiera mañana. <b>¡Que empiece la fiesta de la pizza!</b>" 
    }
];

document.addEventListener('DOMContentLoaded', main);

async function main() {
    const versionDisplay = document.getElementById('app-version-display');
    if (versionDisplay) {
        versionDisplay.textContent = `Versión ${APP_VERSION}`;
    }
    
    const showMotivationalModal = () => {
        const today = new Date().toISOString().split('T')[0];
        const lastShownDate = localStorage.getItem('motivationalModalLastShown');

        if (lastShownDate !== today) {
            const randomModal = PROMOTIONAL_MODALS[Math.floor(Math.random() * PROMOTIONAL_MODALS.length)];
            showAlert(randomModal.message, randomModal.title, { className: randomModal.className });
            localStorage.setItem('motivationalModalLastShown', today);
        }
    };
    
    setupEventListeners();
    const calculatorFunctions = initializeCalculators(UI);
    pizzaDataLoader = calculatorFunctions.loadPizzaData;

    StateManager.subscribe((appData) => {
        if (!appData || !Session.businessName) return;
        UI.renderApp(appData, { businessName: Session.businessName, isAdmin: Session.isAdmin });
        if(pizzaDataLoader) pizzaDataLoader(appData);
        saveDataForCurrentDate(appData);
    });

    if (Session.load()) {
        const dateInput = document.getElementById('dateInput');
        const lastDate = localStorage.getItem('ipv_last_selected_date') || new Date().toISOString().split('T')[0];
        Session.currentDate = lastDate;
        if (dateInput) dateInput.value = lastDate;
        UI.showMainApp();
        showMotivationalModal();
        await loadDataForDate(Session.currentDate);
    } else {
        UI.showLoginScreen();
        try {
            const businessList = await ApiClient.getBusinessList();
            UI.populateBusinessSelect(businessList.businesses);
        } catch (e) {
            UI.populateBusinessSelect(null);
        }
    }
}

// ✅ INICIO: Lógica de normalización con mapa persistente para evitar duplicados
function normalizeData(data) {
    if (!data || !data.products) return data;

    const ID_MAP_KEY = `ipv_id_map_${Session.businessName}`;
    let idMap = JSON.parse(localStorage.getItem(ID_MAP_KEY)) || {};
    let mapWasModified = false;

    // Se crea un mapa temporal para consolidar productos por nombre DENTRO de esta carga de datos.
    // Esto soluciona el caso donde un mismo producto numérico se carga de local y nube al mismo tiempo.
    const productConsolidationMap = new Map();

    data.products.forEach(p => {
        if (!p || !p.name) return;

        const isInvalidId = !p.id || typeof p.id !== 'string' || p.id.length < 15;
        let finalId = p.id;

        if (isInvalidId) {
            const oldIdKey = String(p.id);
            if (idMap[oldIdKey]) {
                finalId = idMap[oldIdKey];
            } else {
                const newId = generateUUID();
                idMap[oldIdKey] = newId;
                finalId = newId;
                mapWasModified = true;
            }
        }
        p.id = finalId;

        // Consolidar: Si ya existe un producto con este ID, nos quedamos con el más reciente.
        const existingProduct = productConsolidationMap.get(p.id);
        if (!existingProduct || new Date(p.lastModified || 0) > new Date(existingProduct.lastModified || 0)) {
            if (p.isActive === undefined) {
                p.isActive = true;
            }
            productConsolidationMap.set(p.id, p);
        }
    });

    if (mapWasModified) {
        console.log("Mapa de IDs actualizado y guardado.");
        localStorage.setItem(ID_MAP_KEY, JSON.stringify(idMap));
    }
    
    // Asignar la lista de productos ya consolidada y sin duplicados.
    data.products = Array.from(productConsolidationMap.values());
    
    return data;
}
// ✅ FIN: Lógica de normalización

async function loadDataForDate(dateString) {
    UI.showLoading(`Cargando ${dateString}...`);
    Session.currentDate = dateString;
    localStorage.setItem("ipv_last_selected_date", dateString);
    const storageKey = `ipv_data_${Session.businessName}_${dateString}`;
    
    let localData = null;
    let cloudData = null;

    try { 
        localData = JSON.parse(localStorage.getItem(storageKey)); 
    } catch (e) {
        console.warn("No se pudieron cargar los datos locales o estaban vacíos.");
    }
    
    if (navigator.onLine && Session.businessName !== "local_mode") {
        try {
            const cloudResponse = await ApiClient.getDailyData(Session.businessName, Session.password, dateString);
            if (cloudResponse.status === "success" && cloudResponse.data) {
                cloudData = cloudResponse.data;
            }
        } catch (error) {
            console.error("Error al obtener datos de la nube, se usarán los locales.", error);
        }
    }
    
    let finalData = mergeData(localData, cloudData);

    if (!finalData) {
        finalData = await createNewDayDataFromPrevious(dateString);
    }

    finalData = normalizeData(finalData);

    StateManager.setState(finalData);
    UI.hideLoading();
    UI.updateSyncIndicator(false);
}

function saveDataForCurrentDate(appData) {
    if (!Session.businessName || !Session.currentDate) return;
    localStorage.setItem(`ipv_data_${Session.businessName}_${Session.currentDate}`, JSON.stringify(appData));
    UI.updateSyncIndicator(true);
}

function mergeData(local, cloud) {
    if (!local) return cloud;
    if (!cloud) return local;

    const merged = { ...cloud, ...local };

    const allProducts = new Map();
    [...(cloud.products || []), ...(local.products || [])].forEach(p => {
        if (p && p.id) {
            const existing = allProducts.get(String(p.id));
            if (!existing || new Date(p.lastModified || 0) > new Date(existing?.lastModified || 0)) {
                allProducts.set(String(p.id), p);
            }
        }
    });
    merged.products = Array.from(allProducts.values());

    const allGastos = new Map();
    [...(cloud.gastos || []), ...(local.gastos || [])].forEach(g => {
        if (g && g.id) {
            const existing = allGastos.get(String(g.id));
            if (!existing || new Date(g.lastModified || 0) > new Date(existing?.lastModified || 0)) {
                allGastos.set(String(g.id), g);
            }
        }
    });
    merged.gastos = Array.from(allGastos.values());
    
    const localPizza = local.pizzaCalcs;
    const cloudPizza = cloud.pizzaCalcs;
    if (localPizza && cloudPizza) {
        merged.pizzaCalcs = new Date(localPizza.lastModified || 0) > new Date(cloudPizza.lastModified || 0) ? localPizza : cloudPizza;
    } else {
        merged.pizzaCalcs = localPizza || cloudPizza || {};
    }

    return merged;
}

async function createNewDayDataFromPrevious(currentDateString) {
    const prevDate = new Date(currentDateString + "T12:00:00Z");
    prevDate.setUTCDate(prevDate.getUTCDate() - 1);
    const prevDateString = prevDate.toISOString().split("T")[0];
    const prevStorageKey = `ipv_data_${Session.businessName}_${prevDateString}`;
    let prevDayData = null;
    try { prevDayData = JSON.parse(localStorage.getItem(prevStorageKey)); } catch (e) {}
    
    if (!prevDayData && navigator.onLine && Session.businessName !== "local_mode") {
        try {
            const response = await ApiClient.getDailyData(Session.businessName, Session.password, prevDateString);
            if (response.status === "success") prevDayData = response.data;
        } catch (e) {}
    }
    
    if (prevDayData && prevDayData.products) {
        const prods = prevDayData.products.filter(p => p.isActive !== false).map(p => {
            const finalValue = typeof p.finales === 'number' ? p.finales : (p.start || 0);
            return {
                ...p,
                start: finalValue,
                entrada: 0,
                finales: finalValue,
                vendido: 0,
                importe: 0,
                ganancias: 0,
                lastModified: new Date().toISOString()
            };
        });
        
        return {
            products: prods,
            gastos: [],
            notas: "",
            user: prevDayData.user || "",
            categories: prevDayData.categories || [],
            predefinedNotes: {},
            pizzaCalcs: {},
            isClosed: false
        };
    }
    
    return {
        products: [],
        gastos: [],
        notas: "",
        user: "",
        categories: [],
        predefinedNotes: {},
        pizzaCalcs: {},
        isClosed: false
    };
}

function setupEventListeners() {
    document.body.addEventListener("submit", handleFormSubmit);
    document.body.addEventListener("click", handleGlobalClick);
    document.body.addEventListener("change", handleGlobalChange);
    
    document.body.addEventListener('click', (e) => {
        if (e.target.tagName === 'INPUT' && (e.target.type === 'text' || e.target.type === 'number' || e.target.type === 'password' || e.target.type === 'email')) {
            e.target.select();
        }
    });

    document.getElementById("searchInput")?.addEventListener("keyup", e => UI.filterProducts(e.target.value));
    
    let notesTimeout;
    document.getElementById("notas-dia")?.addEventListener("input", e => {
        clearTimeout(notesTimeout);
        notesTimeout = setTimeout(() => StateManager.updateNotes(e.target.value), 300);
    });

    document.getElementById('menu-toggle')?.addEventListener('change', e => {
        if (!e.target.checked) {
            const menu = document.querySelector('.header-menu');
            if (menu) menu.scrollTop = 0;
        }
    });

    const scrollToTopBtn = document.getElementById('scrollToTopBtn');
    const scrollToBottomBtn = document.getElementById('scrollToBottomBtn');
    let scrollTimeout;

    const handleScrollButtonsVisibility = () => {
        const scrollPosition = window.scrollY;
        const pageHeight = document.documentElement.scrollHeight;
        const viewportHeight = window.innerHeight;
        const atBottom = (viewportHeight + scrollPosition) >= (pageHeight - 100);
        const awayFromTop = scrollPosition > 100;

        scrollToTopBtn.classList.toggle('visible', awayFromTop);
        scrollToBottomBtn.classList.toggle('visible', !awayFromTop && !atBottom);
    };

    let lastScrollTop = 0;
    const header = document.getElementById('header');
    window.addEventListener('scroll', () => {
        if (scrollTimeout) clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(() => {
            handleScrollButtonsVisibility();
            let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            if (scrollTop > lastScrollTop && scrollTop > 100) {
                header.classList.add('header-hidden');
            } else {
                header.classList.remove('header-hidden');
            }
            lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
        }, 100);
    }, false);

    scrollToTopBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    scrollToBottomBtn.addEventListener('click', () => window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' }));
}

function handleFormSubmit(e) {
    e.preventDefault();
    const targetId = e.target.id;
    if (targetId === 'loginForm') handleLogin();
    else if (targetId === 'createForm') handleCreateBusiness();
    else if (targetId === 'pinForm') verifyPin();
    else if (targetId === 'addProductForm') addProduct();
    else if (targetId === 'addGastoForm') addGasto();
}

function handleGlobalClick(e) {
    const target = e.target.closest("[data-action], .modal-backdrop, .modal .close, .filter-buttons button");
    if (!target) return;

    const action = target.dataset.action;

    if (action) {
        if (action.startsWith('bc_')) {
            handleBillCounterActions(action, UI);
            return;
        }

        switch (action) {
            case "test-promo-modal": {
                const index = parseInt(target.dataset.index, 10);
                if (!isNaN(index) && PROMOTIONAL_MODALS[index]) {
                    const modalData = PROMOTIONAL_MODALS[index];
                    showAlert(modalData.message, modalData.title, { className: modalData.className });
                }
                break;
            }
            case "deleteProduct": {
                const row = target.closest('tr');
                const productId = row?.dataset.productId;
                if (!productId) return;
                const productName = StateManager.getState().products.find(p => String(p.id) === String(productId))?.name || "el producto";
                showConfirm(`¿Estás seguro de que quieres eliminar "${productName}"?`).then(confirmed => {
                    if (confirmed) StateManager.deleteProductById(productId);
                });
                break;
            }
            case "deleteGasto": {
                const gastoId = target.dataset.gastoId;
                if (!gastoId) return;
                const gastoName = StateManager.getState().gastos.find(g => String(g.id) === String(gastoId))?.description || "el gasto";
                showConfirm(`¿Estás seguro de que quieres eliminar "${gastoName}"?`).then(confirmed => {
                    if (confirmed) StateManager.deleteGastoById(gastoId);
                });
                break;
            }
            case "switchToCreate": UI.switchLoginView(true); break;
            case "switchToLogin": UI.switchLoginView(false); break;
            case "localMode": startLocalMode(); break;
            case "deleteBusinessBtn": handleDeleteBusiness(); break;
            case "prevDayBtn": changeDay(-1); break;
            case "nextDayBtn": changeDay(1); break;
            case "toggle-admin-mode": toggleAdminMode(); break;
            case "addProductBtn": UI.toggleModal("product-modal", true); break;
            case "addGastoBtn": UI.toggleModal("gastos-modal", true); break;
            case "deleteSelectedBtn": handleDeleteSelected(); break;
            case "toggleAllBtn": UI.toggleAllCategories(); break;
            case "showZeroStockBtn": handleShowZeroStock(); break;
            case "openCalculatorBtn": UI.toggleModal("calculatorModal", true); break;
            case "openBillCounterBtn": UI.toggleModal("billCounterModal", true); break;
            case "syncButton": syncToCloud(); break;
            case "logoutBtn": logout(); break;
            case "menu-audit-costs": handleAuditCosts(); break;
            case "menu-audit-products": UI.toggleModal('dataAuditModal', true); break;
            case "runAuditBtn": runProductAudit(); break;
            case "menu-reset-day": handleResetDay(); break;
            case "menu-end-of-day": handleEndOfDay(); break;
            case "menu-clear-cache": handleClearCache(); break;
            case "menu-financial-summary": handleFinancialSummary(); break;
            case "menu-performance-report": UI.toggleModal('performanceReportModal', true); break;
            case "generatePerformanceReportBtn": generatePerformanceReport(); break;
            case "menu-compare-periods": UI.toggleModal('comparisonModal', true); break;
            case "runComparisonBtn": runComparison(); break;
            case "menu-copy-report": handleCopyReport(); break;
            case "menu-export-day": handleExportDay(); break;
            case "menu-import-day": handleImportDay(); break;
            case "menu-about": handleShowAbout(); break;
        }
    } else if (target.matches(".modal-backdrop, .modal .close")) {
        const modalId = target.closest(".modal")?.id;
        if (modalId && !['alertModal', 'confirmModal', 'promptModal'].includes(modalId)) {
            UI.toggleModal(modalId, false);
        }
    } else if (target.matches(".filter-buttons button")) {
        const period = target.dataset.period;
        if (period) handleFinancialSummary(period);
    }
}

function handleGlobalChange(e) {
    const target = e.target;
    if (target.matches("#product-list input[data-field]")) {
        const { productId, field } = target.dataset;
        if (productId && field) {
            StateManager.updateProductFieldById(productId, field, target.value);
        }
    } else if (target.id === "selectAllCheckbox") {
        UI.toggleAllCheckboxes(target.checked);
    }

    switch (target.id) {
        case "dateInput": loadDataForDate(target.value); break;
        case "userSelector": StateManager.updateUser(target.value); break;
    }

    if (target.matches("[data-note-key]")) {
        StateManager.updatePredefinedNote(target.dataset.noteKey, target.value);
    }
    if (target.matches("#note-diferencia-tipo, #note-diferencia-monto")) {
        const tipo = document.getElementById("note-diferencia-tipo")?.value;
        const monto = document.getElementById("note-diferencia-monto")?.value;
        StateManager.updateDiferenciaCaja(tipo, monto);
    }
}


async function handleLogin() {
    const businessName = document.getElementById('businessSelect')?.value;
    const password = document.getElementById('passwordInput')?.value;
    if (!businessName || !password) return showAlert('Completa todos los campos.');
    
    UI.showLoading('Iniciando sesión...');
    try {
        const response = await ApiClient.login(businessName, password);
        if (response.status === 'success') {
            Session.businessName = businessName;
            Session.password = password;
            Session.save();
            window.location.reload();
        } else {
            throw new Error(response.message);
        }
    } catch (error) {
        UI.hideLoading();
        if (error.message.includes("Failed to fetch") || error.message.includes("Error de red")) {
            const confirmed = await showConfirm(`Error de conexión. ¿Deseas continuar en modo offline con los datos guardados en este dispositivo para '${businessName}'?`);
            if (confirmed) {
                Session.businessName = businessName;
                Session.password = password;
                Session.save();
                window.location.reload();
            }
        } else {
            await showAlert(`Error al iniciar sesión: ${error.message}`);
        }
    }
}

async function handleCreateBusiness(){
    const name = document.getElementById("newBusinessName")?.value.trim();
    const pass = document.getElementById("newPassword")?.value;
    const key = document.getElementById("creationKeyInput")?.value;
    const email = document.getElementById("newAdminEmail")?.value.trim();

    if(!name||!pass||!key||!email) return showAlert("Todos los campos son obligatorios.");
    if("Pinga1239.45" !== key) return showAlert("Clave Maestra incorrecta.");

    UI.showLoading(`Creando ${name}...`);
    try{
        const response=await ApiClient.createBusiness(name,pass,key,email);
        if(response.status === "success"){
            await showAlert(`¡Negocio "${name}" creado con éxito!`);
            UI.switchLoginView(false);
            const businessList = await ApiClient.getBusinessList();
            UI.populateBusinessSelect(businessList.businesses);
        } else {
            throw new Error(response.message);
        }
    } catch(error){
        await showAlert(`Error al crear: ${error.message}`);
    } finally {
        UI.hideLoading();
    }
}

async function handleDeleteBusiness(){
    const businessName = document.getElementById("businessSelect")?.value;
    if(!businessName) return showAlert("Por favor, selecciona un negocio para eliminar.");

    const key = await showPrompt(`ADVERTENCIA: Estás a punto de eliminar PERMANENTEMENTE el negocio '${businessName}' y TODOS sus datos.\n\nEsta acción NO se puede deshacer.\n\nIntroduce la Clave Maestra para confirmar:`);
    if(!key) return;

    UI.showLoading(`Eliminando ${businessName}...`);
    try{
        const response=await ApiClient.deleteBusiness(businessName,key);
        if(response.status === "success"){
            await showAlert(response.message);
            Object.keys(localStorage).forEach(k=>{
                if(k.startsWith(`ipv_data_${businessName}_`))localStorage.removeItem(k);
            });
            localStorage.removeItem("ipv_business_list_cache");
            window.location.reload();
        } else {
            throw new Error(response.message);
        }
    } catch(err){
        await showAlert(`Error al eliminar: ${err.message}`);
    } finally {
        UI.hideLoading();
    }
}

async function syncToCloud(){
    if(!Session.businessName||Session.businessName==="local_mode") return showAlert("Inicia sesión en un negocio en la nube para sincronizar.");
    if(!navigator.onLine) return showAlert("No hay conexión a internet para sincronizar.");

    UI.updateSyncIndicator(true,true);
    const currentData=StateManager.getState();
    try {
        const response=await ApiClient.sync(Session.businessName,Session.password,Session.currentDate,currentData);
        if(response.status === "success" && response.syncedData){
            const syncedAndNormalizedData = normalizeData(response.syncedData);
            StateManager.setState(syncedAndNormalizedData);
            await showAlert("Sincronización completada correctamente.", "Éxito");
            UI.updateSyncIndicator(false,false);
        } else if(response.status !== "in_progress"){
            await showAlert(`Fallo en sincronización: ${response.message||"Error desconocido"}`);
            UI.updateSyncIndicator(true,false);
        } else {
            UI.updateSyncIndicator(true,false);
        }
    } catch (error) {
        await showAlert(`Error de red durante la sincronización: ${error.message}`);
        UI.updateSyncIndicator(true,false);
    }
}

async function startLocalMode(){
    const confirmed = await showConfirm("¿Activar modo local? Los datos no se guardarán en la nube y solo estarán en este dispositivo.");
    if(confirmed){
        Session.businessName="local_mode";
        Session.password=null;
        Session.save();
        window.location.reload();
    }
}

function changeDay(offset){
    const d=new Date(Session.currentDate+"T12:00:00Z");
    d.setUTCDate(d.getUTCDate()+offset);
    const newDate = d.toISOString().split("T")[0];
    document.getElementById("dateInput").value = newDate;
    loadDataForDate(newDate);
}

async function logout(){
    const confirmed = await showConfirm("¿Estás seguro de que quieres cerrar sesión? Los cambios no sincronizados podrían perderse.");
    if(confirmed){
        Session.clear();
        window.location.reload();
    }
}

async function toggleAdminMode(){
    if(Session.isAdmin){
        Session.isAdmin=false;
        await showAlert("Modo Admin DESACTIVADO.");
    } else {
        UI.toggleModal("pinModal",true);
    }
    StateManager.setState(StateManager.getState()); 
}

async function verifyPin(){
    const pinInput = document.getElementById("pinInput");
    if("8608" === pinInput.value){
        Session.isAdmin=true;
        await showAlert("Modo Admin ACTIVADO.");
        UI.toggleModal("pinModal",false);
        pinInput.value="";
        StateManager.setState(StateManager.getState()); 
    } else {
        await showAlert("PIN incorrecto.");
        pinInput.value="";
    }
}

function addProduct(){
    const nameInput=document.getElementById("modal-product-name");
    const categorySelect=document.getElementById("modal-product-category");
    const startInput=document.getElementById("modal-product-start");
    const costInput=document.getElementById("modal-product-cost");
    const priceInput=document.getElementById("modal-product-price");

    const names=nameInput.value.split(",").map(n=>n.trim()).filter(Boolean);
    if(names.length===0) return showAlert("Introduce al menos un nombre de producto.");

    StateManager.addProduct({
        names,
        category: categorySelect.value,
        start: Number(startInput.value) || 0,
        cost: parseFloat(costInput.value) || 0,
        price: parseFloat(priceInput.value) || 0
    });

    UI.toggleModal("product-modal",false);
    nameInput.value="";
    startInput.value="";
    costInput.value="";
    priceInput.value="";
}

function addGasto(){
    const typeInput = document.getElementById("gasto-type");
    const descriptionInput = document.getElementById("gastos-description");
    const amountInput = document.getElementById("gastos-amount");
    
    const type = typeInput.value;
    const description = descriptionInput.value.trim();
    const amount = parseFloat(amountInput.value);

    if(description && !isNaN(amount) && amount > 0){
        StateManager.addGasto(description, amount, type);
        UI.toggleModal("gastos-modal", false);
        descriptionInput.value = "";
        amountInput.value = "";
        typeInput.value = "gasto";
    } else {
        showAlert("Por favor, introduce una descripción válida y un monto positivo.");
    }
}

async function handleDeleteSelected() {
    const selectedIds = UI.getSelectedProductIds();
    if (selectedIds.size === 0) {
        return showAlert("No has seleccionado ningún producto para eliminar.");
    }
    const confirmed = await showConfirm(`¿Estás seguro de que quieres eliminar ${selectedIds.size} productos?`);
    if (confirmed) {
        const idsAsStrings = new Set(Array.from(selectedIds, id => String(id)));
        StateManager.deleteSelectedProducts(idsAsStrings);
    }
}

function handleShowZeroStock() {
    const zeroStockProducts = StateManager.getState().products.filter(p => p.isActive !== false && p.finales === 0);
    UI.renderZeroStockList(zeroStockProducts);
    UI.toggleModal('zeroStockModal', true);
}

function handleAuditCosts() {
    const zeroCostProducts = StateManager.getState().products.filter(p => p.isActive !== false && (p.cost === 0 || p.cost === null || p.cost === undefined));
    UI.renderZeroCostList(zeroCostProducts);
    UI.toggleModal('zeroCostModal', true);
}

async function runProductAudit() {
    const productName = document.getElementById('audit-product-name').value.trim().toLowerCase();
    if (!productName) return showAlert('Por favor, escribe el nombre de un producto.');
    UI.showLoading('Buscando en el historial...');
    const allData = getAllHistoricalData(Session.businessName);
    const history = [];
    allData.forEach(day => {
        day.data.products?.forEach(p => {
            if (p.name.toLowerCase().includes(productName)) {
                history.push({ date: day.date, product: p });
            }
        });
    });
    UI.renderAuditResults(history, productName);
    UI.hideLoading();
}

async function handleResetDay() {
    const confirmed = await showConfirm(
        "¿Seguro que quieres reiniciar este día?\n\nSe borrarán todos los movimientos (entradas, gastos, notas) y se recalculará el inventario inicial basándose en los finales del día anterior. El día quedará abierto para edición."
    );
    if (confirmed) {
        UI.showLoading('Reiniciando día...');
        try {
            const newData = await createNewDayDataFromPrevious(Session.currentDate);
            StateManager.setState(newData);
            showAlert("Día reiniciado correctamente.");
        } catch (error) {
            showAlert("Hubo un error al reiniciar el día.");
            console.error("Error en handleResetDay:", error);
        } finally {
            UI.hideLoading();
        }
    }
}

async function handleEndOfDay() {
    const data = StateManager.getState();
    if (data.isClosed) {
        showAlert("Este día ya ha sido cerrado.");
        return;
    }

    const totalImporte = data.products.reduce((sum, p) => sum + (p.importe || 0), 0);
    const gastosOperativos = data.gastos.filter(g => g.type !== 'recogida' && g.isActive !== false).reduce((sum, g) => sum + (g.amount || 0), 0);
    const neto = totalImporte - gastosOperativos;
    const confirmed = await showConfirm(
        `CIERRE DE DÍA\n\n- Ingresos Brutos: $${totalImporte.toFixed(2)}\n- Gastos Operativos: $${gastosOperativos.toFixed(2)}\n- Neto Operativo: $${neto.toFixed(2)}\n\n¿Confirmar cierre? Una vez cerrado, no podrás editar este día (a menos que lo reinicies).`,
        "Confirmar Cierre de Día"
    );

    if (confirmed) {
        StateManager.closeDay();
        showAlert("Día cerrado exitosamente. Se recomienda sincronizar los datos.");
    }
}

async function handleClearCache() {
    const confirmed = await showConfirm("ADVERTENCIA: Estás a punto de borrar TODOS los datos de este negocio guardados en ESTE NAVEGADOR. Esto no afecta los datos en la nube. ¿Continuar?");
    if (confirmed) {
        const businessName = Session.businessName;
        const key = await showPrompt(`Para confirmar, escribe el nombre del negocio: "${businessName}"`);
        if (key === businessName) {
            UI.showLoading('Limpiando caché local...');
            Object.keys(localStorage).forEach(k => {
                if (k.startsWith(`ipv_data_${businessName}_`) || k.startsWith(`ipv_id_map_${businessName}`)) {
                    localStorage.removeItem(k);
                }
            });
            Session.clear();
            UI.hideLoading();
            await showAlert("Caché local para este negocio ha sido limpiado. La página se recargará.");
            window.location.reload();
        } else if (key !== null) {
            await showAlert("El nombre no coincide. Operación cancelada.");
        }
    }
}

async function handleCopyReport() {
    const data = StateManager.getState();
    let report = `📋 REPORTE DEL DÍA: ${Session.currentDate}\n`;
    report += `🧑‍💼 Dependiente: ${data.user || 'No asignado'}\n`;
    report += `================================\n\n`;

    const totalImporte = data.products.reduce((sum, p) => sum + (p.importe || 0), 0);
    const totalGanancias = data.products.reduce((sum, p) => sum + (p.ganancias || 0), 0);
    
    const activeGastos = data.gastos.filter(g => g.isActive !== false);
    const gastosOperativos = activeGastos.filter(g => g.type !== 'recogida');
    const recogidas = activeGastos.filter(g => g.type === 'recogida');
    const totalGastosOp = gastosOperativos.reduce((sum, g) => sum + g.amount, 0);
    const totalRecogidas = recogidas.reduce((sum, g) => sum + g.amount, 0);

    report += `📊 RESUMEN FINANCIERO\n`;
    report += `  - Ingresos Brutos: $${totalImporte.toFixed(2)}\n`;
    if(Session.isAdmin) {
        report += `  - Ganancia Bruta (Productos): $${totalGanancias.toFixed(2)}\n`;
        report += `  - Gastos Operativos: $${totalGastosOp.toFixed(2)}\n`;
        report += `  - Ganancia Neta: $${(totalGanancias - totalGastosOp).toFixed(2)}\n`;
    }
    report += `  - Total Recogidas: $${totalRecogidas.toFixed(2)}\n`;
    report += `  - Efectivo en Caja (Teórico): $${(totalImporte - totalGastosOp - totalRecogidas).toFixed(2)}\n\n`;
    
    report += `📦 VENTAS DETALLADAS\n`;
    data.products.forEach(p => {
        if (p.isActive !== false && p.vendido > 0) {
            report += `  - ${p.name}: ${p.vendido} x $${p.price.toFixed(2)} = $${p.importe.toFixed(2)}\n`;
        }
    });
    report += `\n`;

    if (gastosOperativos.length > 0) {
        report += `💸 GASTOS OPERATIVOS\n`;
        gastosOperativos.forEach(g => {
            report += `  - ${g.description}: $${g.amount.toFixed(2)}\n`;
        });
        report += `\n`;
    }
    if (recogidas.length > 0) {
        report += `💰 RECOGIDAS DE EFECTIVO\n`;
        recogidas.forEach(g => {
            report += `  - ${g.description}: $${g.amount.toFixed(2)}\n`;
        });
        report += `\n`;
    }

    if (data.notas) {
        report += `📝 NOTAS ADICIONALES\n${data.notas}\n\n`;
    }
    
    report += `================================\n`;
    report += `Sistema de Gestión IPV`;

    navigator.clipboard.writeText(report).then(
        async () => { await showAlert("Reporte copiado al portapapeles."); },
        async () => { await showAlert("Error al copiar el reporte."); }
    );
}

function handleExportDay() {
    const data = StateManager.getState();
    const dataStr = JSON.stringify(data, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ipv_data_${Session.businessName}_${Session.currentDate}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function handleImportDay() {
    const fileInput = document.getElementById('file-input');
    fileInput.onchange = e => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = async event => {
            try {
                const importedData = JSON.parse(event.target.result);
                const confirmed = await showConfirm("Se cargará el archivo. Los datos actuales de este día se sobrescribirán. ¿Continuar?");
                if(confirmed) {
                    StateManager.setState(importedData);
                    await showAlert("Datos importados correctamente.");
                }
            } catch (err) {
                await showAlert("Error: El archivo no es un JSON válido.");
            }
        };
        reader.readAsText(file);
    };
    fileInput.click();
}

function handleShowAbout() {
    const content = `
        <div style="text-align: center;">
            <h3>Versión ${APP_VERSION}</h3>
            <p>Sistema de Gestión de Inventario y Punto de Venta.</p>
        </div>
        <hr style="border-color: var(--border-glass); margin: 15px 0;">
        <h4>Historial de Cambios Recientes:</h4>
        <ul style="list-style-position: inside; padding-left: 10px; font-size: 0.9em; text-align: left;">
            <li><b>v${APP_VERSION} (Solución Duplicados Definitiva):</b>
                <ul>
                    <li>Implementado un mapa de IDs persistente para garantizar que los productos antiguos siempre se conviertan al mismo UUID, eliminando la causa raíz de la duplicación.</li>
                </ul>
            </li>
            <li><b>v10.20 (Resaltado de Filas):</b>
                 <ul>
                    <li>Re-implementado el resaltado de filas para errores (finales > stock) y stock cero.</li>
                </ul>
            </li>
            <li><b>v10.18 (Estabilidad y Correcciones):</b>
                <ul>
                    <li>Normalización de IDs para arreglar errores de edición/borrado.</li>
                    <li>Lógica de actualización basada en IDs únicos.</li>
                    <li>Corregido error que impedía modificar el precio.</li>
                </ul>
            </li>
        </ul>
    `;
    showAlert(content, "Acerca de IPV Gestión");
}

function handleFinancialSummary(period = 'week') {
    const allData = getFilteredHistoricalData(null, null, Session.businessName);
    UI.renderFinancialSummary(allData, period);
    UI.toggleModal('financialSummaryModal', true);
}

async function generatePerformanceReport() {
    const start = document.getElementById('perf-start-date').value;
    const end = document.getElementById('perf-end-date').value;
    if (!start || !end) return showAlert('Selecciona un rango de fechas.');
    const data = getFilteredHistoricalData(start, end, Session.businessName);
    const productMap = new Map();
    data.forEach(day => {
        day.data.products?.forEach(p => {
            if (p.vendido > 0) {
                const existing = productMap.get(p.name) || { name: p.name, totalVendido: 0, totalImporte: 0, totalGanancias: 0 };
                existing.totalVendido += p.vendido;
                existing.totalImporte += p.importe;
                existing.totalGanancias += p.ganancias;
                productMap.set(p.name, existing);
            }
        });
    });
    const reportData = Array.from(productMap.values());
    UI.renderPerformanceReport(reportData, start, end);
}

async function runComparison() {
    const a_start = document.getElementById('comp-a-start').value;
    const a_end = document.getElementById('comp-a-end').value;
    const b_start = document.getElementById('comp-b-start').value;
    const b_end = document.getElementById('comp-b-end').value;
    if (!a_start || !a_end || !b_start || !b_end) return showAlert('Completa todos los rangos de fecha.');
    const calculateTotals = (start, end) => {
        const data = getFilteredHistoricalData(start, end, Session.businessName);
        let totals = { ingresos: 0, gastos: 0, ganancias: 0, dias: data.length };
        data.forEach(day => {
            day.data.products?.forEach(p => {
                totals.ingresos += p.importe || 0;
                totals.ganancias += p.ganancias || 0;
            });
            day.data.gastos?.forEach(g => {
                if(g.type !== 'recogida' && g.isActive !== false) totals.gastos += g.amount || 0;
            });
        });
        return totals;
    };
    const periodA = calculateTotals(a_start, a_end);
    const periodB = calculateTotals(b_start, b_end);
    UI.renderComparisonReport({ periodA, periodB }, {a_start, a_end, b_start, b_end});
}