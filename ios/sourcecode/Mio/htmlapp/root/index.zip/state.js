// js/state.js
import { generateUUID } from './utils.js';

let appData = {};
let subscribers = [];

const StateManager = {
    subscribe(callback) {
        subscribers.push(callback);
    },

    _notify() {
        const stateCopy = this.getState();
        subscribers.forEach(callback => callback(stateCopy));
    },

    getState() {
        return JSON.parse(JSON.stringify(appData));
    },

    setState(data) {
        appData = data || {};
        this._notify();
    },
    
    // ✅ CORRECCIÓN: Función refactorizada para usar productId en lugar de index. Es más robusto.
    updateProductFieldById(productId, field, value) {
        if (appData.isClosed) return;

        const p = appData.products?.find(prod => String(prod.id) === String(productId));
        if (!p) {
            console.error(`Producto con ID ${productId} no encontrado para actualizar.`);
            return;
        }
        
        const numericValue = Number(value);
        const floatValue = parseFloat(value);

        if (field === 'finales') {
            p[field] = value === '' ? null : (isNaN(numericValue) ? null : numericValue);
        } else if (['start', 'entrada'].includes(field)) {
            p[field] = isNaN(numericValue) ? 0 : numericValue;
        } else if (['cost', 'price'].includes(field)) {
            p[field] = isNaN(floatValue) ? 0 : floatValue;
        } else {
            p[field] = value; 
        }
        
        const start = Number(p.start || 0);
        const entrada = Number(p.entrada || 0);
        const cost = Number(p.cost || 0);
        const price = Number(p.price || 0);
        
        p.vendido = (typeof p.finales === 'number') ? Math.max(0, start + entrada - p.finales) : 0;
        p.importe = p.vendido * price;
        p.ganancias = p.importe - (p.vendido * cost);
        p.lastModified = new Date().toISOString();
        
        this._notify();
    },

    addProduct(productDetails) {
        const { names, category, start, cost, price } = productDetails;
        if (!appData.products) appData.products = [];
        if (!appData.categories) appData.categories = [];

        names.forEach(name => {
            const startValue = Number(start) || 0;
            appData.products.push({
                id: generateUUID(),
                name, category, 
                start: startValue, 
                cost: Number(cost) || 0, 
                price: Number(price) || 0,
                entrada: 0, 
                finales: startValue, 
                vendido: 0, importe: 0, ganancias: 0,
                isActive: true,
                lastModified: new Date().toISOString()
            });
        });
        
        if (category && !appData.categories.includes(category)) {
            appData.categories.push(category);
        }
        
        this._notify();
    },

    addGasto(description, amount, type) {
        if (!appData.gastos) appData.gastos = [];
        appData.gastos.push({
            id: generateUUID(),
            description, 
            amount,
            type: type || 'gasto',
            isActive: true,
            lastModified: new Date().toISOString()
        });
        this._notify();
    },

    deleteProductById(productId) {
        const product = appData.products?.find(p => String(p.id) === String(productId));
        if (product) {
            product.isActive = false;
            product.lastModified = new Date().toISOString();
            this._notify();
        }
    },
    
    deleteSelectedProducts(idsToDelete) {
        let changed = false;
        appData.products.forEach(p => {
            if (idsToDelete.has(String(p.id))) {
                p.isActive = false;
                p.lastModified = new Date().toISOString();
                changed = true;
            }
        });
        if (changed) this._notify();
    },

    deleteGastoById(gastoId) {
        const gasto = appData.gastos.find(g => String(g.id) === String(gastoId));
        if (gasto) {
            gasto.isActive = false;
            gasto.lastModified = new Date().toISOString();
            this._notify();
        }
    },
    
    resetDay() {
        if (appData.products) {
            appData.products.forEach(p => {
                p.entrada = 0;
                p.finales = p.start;
                p.vendido = 0;
                p.importe = 0;
                p.ganancias = 0;
                p.lastModified = new Date().toISOString();
            });
        }
        appData.gastos = [];
        appData.notas = "";
        appData.predefinedNotes = {};
        appData.pizzaCalcs = {};
        appData.isClosed = false;
        this._notify();
    },

    closeDay() {
        appData.isClosed = true;
        this._notify();
    },

    updateNotes(newNotes) {
        if (appData.notas !== newNotes) {
            appData.notas = newNotes;
            this._notify();
        }
    },
    
    updateUser(newUser) {
        appData.user = newUser;
        this._notify();
    },
    
    updateDiferenciaCaja(tipo, monto) {
        if (!appData.predefinedNotes) appData.predefinedNotes = {};
        const montoVal = tipo === 'ninguna' ? 0 : parseFloat(monto) || 0;
        appData.predefinedNotes.diferenciaCaja = { tipo, monto: montoVal };
        this._notify();
    },

    updatePizzaCalcs(pizzaData) {
        appData.pizzaCalcs = {
            ...pizzaData,
            lastModified: new Date().toISOString()
        };
        this._notify();
    }
};

export default StateManager;