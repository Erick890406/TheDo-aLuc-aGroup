// js/ui.js
import StateManager from './state.js';

let collapsedCategories = new Set();
let areAllCategoriesCollapsed = false;

export function toggleModal(id, show) {
  const modal = document.getElementById(id);
  if (!modal) return;
  modal.style.display = show ? 'flex' : 'none';
  if (show) {
    const firstInput = modal.querySelector('input:not([type=hidden]), select');
    firstInput?.focus();
  } else {
    modal.querySelectorAll('.modal-scrollable-content').forEach(el => (el.scrollTop = 0));
  }
  document.body.style.overflow = show ? 'hidden' : '';
}

export function showLoading(msg) {
  const msgEl = document.getElementById('loadingMessage');
  const overlay = document.getElementById('loadingOverlay');
  if (msgEl) msgEl.textContent = msg || 'Procesando...';
  if (overlay) overlay.style.display = 'flex';
}

export function hideLoading() {
  const overlay = document.getElementById('loadingOverlay');
  if (overlay) overlay.style.display = 'none';
}

export function updateSyncIndicator(hasChanges, isSyncing = false) {
  const syncIndicator = document.getElementById('sync-indicator');
  const syncButton = document.getElementById('syncButton');
  if (syncIndicator) {
    syncIndicator.style.backgroundColor = isSyncing ? '#3498db' : (hasChanges ? '#f39c12' : '#28a745');
    syncIndicator.title = isSyncing ? 'Sincronizando...' : (hasChanges ? 'Cambios locales pendientes' : 'Sincronizado');
  }
  if (syncButton) {
    syncButton.disabled = isSyncing;
    syncButton.textContent = isSyncing ? 'Sincronizando...' : 'Sincronizar';
  }
}

export function switchLoginView(showCreate) {
  document.getElementById('loginForm')?.classList.toggle('hidden', showCreate);
  document.getElementById('createForm')?.classList.toggle('hidden', !showCreate);
}

export function showMainApp() {
  document.getElementById('login-screen-wrapper').style.display = 'none';
  document.getElementById('header').style.display = 'flex';
  document.getElementById('container').style.display = 'block';
}

export function showLoginScreen() {
  document.getElementById('login-screen-wrapper').style.display = 'flex';
  document.getElementById('header').style.display = 'none';
  document.getElementById('container').style.display = 'none';
}

export function populateBusinessSelect(businesses) {
    const select = document.getElementById('businessSelect');
    if (!select) return;
    if (businesses === null) {
        select.innerHTML = '<option value="">Error de conexión</option>';
        select.disabled = true;
        return;
    }
    select.innerHTML = '<option value="">Seleccionar negocio...</option>';
    if (businesses?.length > 0) {
        select.innerHTML += businesses.map(name => `<option value="${name}">${name.replace(/_/g, ' ')}</option>`).join('');
        select.disabled = false;
    } else {
        select.innerHTML = '<option value="">No hay negocios creados</option>';
        select.disabled = true;
    }
}

export function renderApp(appData, session) {
    if (!appData || !session || !session.businessName) return;
    
    document.getElementById('businessTitle').textContent = `IPV - ${session.businessName.replace(/_/g, ' ')}`;
    const userSelector = document.getElementById('userSelector');
    userSelector.value = appData.user || '';
    document.getElementById('worker-display').textContent = userSelector.options[userSelector.selectedIndex]?.text || "Seleccionar...";
    
    const notasDia = document.getElementById('notas-dia');
    if (notasDia && document.activeElement !== notasDia) {
      notasDia.value = appData.notas || '';
    }
    
    const diferencia = appData.predefinedNotes?.diferenciaCaja || { tipo: 'ninguna', monto: 0 };
    document.getElementById('note-diferencia-tipo').value = diferencia.tipo;
    const montoInput = document.getElementById('note-diferencia-monto');
    montoInput.value = diferencia.monto || '';
    montoInput.disabled = appData.isClosed || diferencia.tipo === 'ninguna';
    
    renderProductTable(appData.products || [], session.isAdmin, appData.isClosed);
    renderGastosList(appData.gastos || [], appData.isClosed);
    calculateAndRenderTotals(appData);
    updateAdminVisibility(session.isAdmin);
    populateCategoryDropdown(appData.categories);
}

function renderProductTable(products, isAdmin, isClosed) {
    const tbody = document.getElementById('product-list');
    if (!tbody) return;
    
    const activeProducts = products.filter(p => p.isActive !== false);
    if (activeProducts.length === 0) {
        tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;padding:20px;">No hay productos. Añade uno para empezar.</td></tr>`;
        return;
    }

    const productsByCategory = activeProducts.reduce((acc, p) => {
        const category = p.category || "General";
        if (!acc[category]) acc[category] = [];
        acc[category].push(p);
        return acc;
    }, {});
    const sortedCategories = Object.keys(productsByCategory).sort((a, b) => a.localeCompare(b));
    
    tbody.innerHTML = "";
    sortedCategories.forEach(category => {
        const isCollapsed = collapsedCategories.has(category);
        const catRow = tbody.insertRow();
        catRow.className = "category-row";
        catRow.innerHTML = `<td colspan="11"><span class="toggle-icon">${isCollapsed ? "►" : "▼"}</span>${category}</td>`;
        catRow.addEventListener('click', () => toggleCategory(category));

        productsByCategory[category].sort((a, b) => a.name.localeCompare(b.name)).forEach(p => {
            const row = createProductRow(p, isAdmin, isClosed);
            if (isCollapsed) row.style.display = "none";
            tbody.appendChild(row);
        });
    });
}

function createProductRow(product, isAdmin, isClosed) {
    const row = document.createElement('tr');
    row.dataset.productId = product.id;
    row.dataset.category = product.category || 'General';

    // ✅ INICIO: Lógica para resaltar filas con errores o stock cero
    const start = Number(product.start || 0);
    const entrada = Number(product.entrada || 0);
    const finales = product.finales;

    // Condición de error: Hay más unidades finales de las que debería haber.
    // Solo se aplica si 'finales' es un número válido.
    if (typeof finales === 'number' && finales > (start + entrada)) {
        row.classList.add('fila-error');
    } 
    // Condición de stock cero: No es un error y las unidades finales son 0.
    else if (typeof finales === 'number' && finales === 0) {
        row.classList.add('fila-stock-cero');
    }
    // ✅ FIN: Lógica para resaltar filas

    const finalesDisplayValue = (finales === null || finales === undefined) ? '' : finales;
    const disabledAttr = isClosed ? 'disabled' : '';
    
    row.innerHTML = `
        <td><input type="checkbox" class="product-select-checkbox" ${disabledAttr}></td>
        <td>${escapeHtml(product.name)}</td>
        <td><input type="number" value="${product.start}" data-field="start" data-product-id="${product.id}" ${disabledAttr}></td>
        <td><input type="number" value="${product.entrada}" data-field="entrada" data-product-id="${product.id}" ${disabledAttr}></td>
        <td><input type="number" value="${finalesDisplayValue}" data-field="finales" data-product-id="${product.id}" ${disabledAttr}></td>
        <td>${product.vendido || 0}</td>
        <td class="admin-only"><input type="number" step="0.01" value="${(product.cost || 0).toFixed(2)}" data-field="cost" data-product-id="${product.id}" ${disabledAttr}></td>
        <td><input type="number" step="0.01" value="${(product.price || 0).toFixed(2)}" data-field="price" data-product-id="${product.id}" ${disabledAttr}></td>
        <td>${(product.importe || 0).toFixed(2)}</td>
        <td class="admin-only">${(product.ganancias || 0).toFixed(2)}</td>
        <td><button class="delete-button" data-action="deleteProduct" ${disabledAttr}>&times;</button></td>`;
    return row;
}

function renderGastosList(gastos, isClosed) {
    const listDiv = document.getElementById('gastos-list');
    listDiv.innerHTML = '';
    const disabledAttr = isClosed ? 'disabled' : '';
    
    gastos.filter(g => g.isActive !== false).forEach((g) => {
        const item = document.createElement('div');
        item.className = 'gasto-item';
        const type = g.type || 'gasto';
        const tagText = type === 'recogida' ? 'Recogida' : 'Gasto';
        
        item.innerHTML = `
            <span>${escapeHtml(g.description || '')} <span class="gasto-tag gasto-type--${type}">${tagText}</span></span>
            <span>$${(g.amount || 0).toFixed(2)}</span>
            <button class="delete-button" data-action="deleteGasto" data-gasto-id="${g.id}" ${disabledAttr}>&times;</button>`;
        listDiv.appendChild(item);
    });
}

function calculateAndRenderTotals(appData) {
    const { products = [], gastos = [] } = appData;
    let totalImporte = 0, totalGanancias = 0, totalStockCost = 0, totalStockValue = 0;
    
    products.filter(p => p.isActive !== false).forEach(p => {
        totalImporte += p.importe || 0;
        totalGanancias += p.ganancias || 0;
        const finales = typeof p.finales === 'number' ? p.finales : p.start;
        totalStockCost += (finales || 0) * (p.cost || 0);
        totalStockValue += (finales || 0) * (p.price || 0);
    });
    
    const activeGastos = gastos.filter(g => g.isActive !== false);
    const gastosOperativos = activeGastos.filter(g => g.type !== 'recogida').reduce((sum, g) => sum + g.amount, 0);
    const recogidas = activeGastos.filter(g => g.type === 'recogida').reduce((sum, g) => sum + g.amount, 0);

    document.getElementById("total-importe").textContent = totalImporte.toFixed(2);
    document.getElementById("total-ganancias").textContent = totalGanancias.toFixed(2);
    document.getElementById("total-gastos-operativos").textContent = gastosOperativos.toFixed(2);
    document.getElementById("ganancia-neta-operativa").textContent = (totalGanancias - gastosOperativos).toFixed(2);
    document.getElementById("total-recogidas").textContent = recogidas.toFixed(2);
    document.getElementById("efectivo-teorico-caja").textContent = (totalImporte - gastosOperativos - recogidas).toFixed(2);
    document.getElementById("total-stock-cost").textContent = totalStockCost.toFixed(2);
    document.getElementById("total-stock-value").textContent = totalStockValue.toFixed(2);
}

export function updateAdminVisibility(isAdmin) {
    document.querySelectorAll(".admin-toggle-btn").forEach(btn => btn.classList.toggle("admin-active", isAdmin));
    document.getElementById("header")?.classList.toggle("admin-mode-active", isAdmin);
    document.querySelectorAll(".admin-only-row").forEach(el => el.style.display = isAdmin ? "" : "none");
    document.querySelectorAll(".admin-only").forEach(el => el.classList.toggle("hidden", !isAdmin));
}

export function filterProducts(term) {
    const lowerCaseTerm = term.toLowerCase();
    document.querySelectorAll('#product-list tr:not(.category-row)').forEach(row => {
        const name = row.cells[1]?.textContent.toLowerCase() || '';
        row.style.display = name.includes(lowerCaseTerm) ? '' : 'none';
    });
}

export function populateCategoryDropdown(categories) {
    const select = document.getElementById('modal-product-category');
    if (!select) return;
    const allCategories = [...new Set(["General", ...(categories || [])])].sort();
    select.innerHTML = allCategories.map(c => `<option value="${c}">${c}</option>`).join('');
}

function toggleCategory(category) {
    collapsedCategories.has(category) ? collapsedCategories.delete(category) : collapsedCategories.add(category);
    areAllCategoriesCollapsed = false;
    const appData = StateManager.getState();
    const isAdmin = document.querySelector('.admin-toggle-btn.admin-active') !== null;
    renderProductTable(appData.products, isAdmin, appData.isClosed);
}

export function toggleAllCategories() {
    areAllCategoriesCollapsed = !areAllCategoriesCollapsed;
    const allCategoriesFromState = new Set(
        (StateManager.getState().products || [])
        .filter(p => p.isActive !== false)
        .map(p => p.category || 'General')
    );
    collapsedCategories = areAllCategoriesCollapsed ? new Set(allCategoriesFromState) : new Set();
    const appData = StateManager.getState();
    const isAdmin = document.querySelector('.admin-toggle-btn.admin-active') !== null;
    renderProductTable(appData.products, isAdmin, appData.isClosed);
}

export function getSelectedProductIds() {
    const ids = new Set();
    document.querySelectorAll('.product-select-checkbox:checked').forEach(checkbox => {
        const row = checkbox.closest('tr');
        if (row && row.dataset.productId) ids.add(row.dataset.productId);
    });
    return ids;
}

export function toggleAllCheckboxes(checked) {
    document.querySelectorAll('.product-select-checkbox').forEach(checkbox => checkbox.checked = checked);
}

function escapeHtml(str) {
  return String(str).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
}

export function renderZeroStockList(products) {
    const list = document.getElementById('zeroStockList');
    list.innerHTML = products.length > 0
        ? products.map(p => `<li>${escapeHtml(p.name)}</li>`).join('')
        : '<li>No hay productos con stock cero.</li>';
}

export function renderZeroCostList(products) {
    const container = document.getElementById('zeroCostListContainer');
    container.innerHTML = products.length > 0
        ? products.map(p => `<div class="gasto-item">${escapeHtml(p.name)} (Categoría: ${p.category})</div>`).join('')
        : '<p>¡Excelente! Todos los productos tienen un costo asignado.</p>';
}

export function renderAuditResults(history, productName) {
    const container = document.getElementById('audit-results');
    if (history.length === 0) {
        container.innerHTML = `<p>No se encontraron registros para "${productName}".</p>`;
        return;
    }
    let html = `<h4>Historial para "${escapeHtml(productName)}":</h4>`;
    history.forEach(item => {
        html += `
            <div class="summary-card">
                <strong>${item.date}</strong><br>
                Inicio: ${item.product.start}, Entrada: ${item.product.entrada}, Final: ${item.product.finales ?? 'N/A'}<br>
                Vendido: ${item.product.vendido}, Importe: $${(item.product.importe || 0).toFixed(2)}
            </div>`;
    });
    container.innerHTML = html;
}

export function renderFinancialSummary(data, period) {
    const container = document.getElementById('summary-content');
    let totals = { ingresos: 0, gastos: 0, ganancias: 0, dias: data.length };
    data.forEach(day => {
        (day.data.products || []).forEach(p => {
            totals.ingresos += p.importe || 0;
            totals.ganancias += p.ganancias || 0;
        });
        (day.data.gastos || []).forEach(g => {
            if (g.type !== 'recogida' && g.isActive !== false) totals.gastos += g.amount || 0;
        });
    });
    const isAdmin = document.querySelector('.admin-toggle-btn.admin-active') !== null;
    container.innerHTML = `
        <div class="summary-card"><h4>Ingresos Brutos</h4><p>$${totals.ingresos.toFixed(2)}</p></div>
        <div class="summary-card"><h4>Gastos Totales</h4><p>$${totals.gastos.toFixed(2)}</p></div>
        <div class="summary-card admin-only-row" style="display: ${isAdmin ? 'block' : 'none'}"><h4>Ganancia Bruta</h4><p>$${totals.ganancias.toFixed(2)}</p></div>
        <div class="summary-card"><h4>Balance Neto</h4><p>$${(totals.ingresos - totals.gastos).toFixed(2)}</p></div>
        <p style="text-align:center; font-size: 0.9em; color: var(--text-muted);">Resultados para ${data.length} día(s).</p>`;
}

export function renderPerformanceReport(reportData, start, end) {
    const container = document.getElementById('performance-content');
    const sortedByVendido = [...reportData].sort((a, b) => b.totalVendido - a.totalVendido);
    const sortedByImporte = [...reportData].sort((a, b) => b.totalImporte - a.totalImporte);
    const sortedByGanancias = [...reportData].sort((a, b) => b.totalGanancias - a.totalGanancias);
    
    const renderList = (title, data, key) => `
        <h4>${title}</h4>
        ${data.slice(0, 10).map(p => `<div class="gasto-item"><span>${escapeHtml(p.name)}</span><strong>${key === 'totalVendido' ? p[key] : '$' + p[key].toFixed(2)}</strong></div>`).join('') || '<p>No hay datos.</p>'}`;
    
    const isAdmin = document.querySelector('.admin-toggle-btn.admin-active') !== null;
    container.innerHTML = `
        <p style="text-align:center;">Mostrando reporte desde ${start} hasta ${end}</p>
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
            <div>${renderList('🏆 Top 10 Más Vendidos (Unidades)', sortedByVendido, 'totalVendido')}</div>
            <div>${renderList('💰 Top 10 Más Ingresos', sortedByImporte, 'totalImporte')}</div>
            <div class="admin-only-row" style="display: ${isAdmin ? 'block' : 'none'}">${renderList('💹 Top 10 Más Rentables', sortedByGanancias, 'totalGanancias')}</div>
        </div>`;
}

export function renderComparisonReport(data, dates) {
    const container = document.getElementById('comparison-results');
    const { periodA, periodB } = data;
    
    const comparisonRow = (label, valA, valB) => {
        const diff = valB - valA;
        const percent = valA !== 0 ? (diff / Math.abs(valA)) * 100 : (valB > 0 ? 100 : 0);
        const color = diff >= 0 ? 'var(--success-color)' : 'var(--danger-color)';
        const icon = diff >= 0 ? '▲' : '▼';
        return `
            <div class="summary-card">
                <h4>${label}</h4>
                <div style="display:flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                    <span>A: $${valA.toFixed(2)}</span>
                    <span>B: $${valB.toFixed(2)}</span>
                    <strong style="color:${color};">${icon} ${diff.toFixed(2)} (${percent.toFixed(1)}%)</strong>
                </div>
            </div>`;
    };
    
    const isAdmin = document.querySelector('.admin-toggle-btn.admin-active') !== null;
    container.innerHTML = `
        <p style="text-align:center;">
            <strong>Periodo A:</strong> ${dates.a_start} a ${dates.a_end} (${periodA.dias} días) <br>
            <strong>Periodo B:</strong> ${dates.b_start} a ${dates.b_end} (${periodB.dias} días)
        </p>
        ${comparisonRow('Ingresos', periodA.ingresos, periodB.ingresos)}
        ${comparisonRow('Gastos', periodA.gastos, periodB.gastos)}
        <div class="admin-only-row" style="display: ${isAdmin ? 'block' : 'none'}">${comparisonRow('Ganancias', periodA.ganancias, periodB.ganancias)}</div>
    `;
}