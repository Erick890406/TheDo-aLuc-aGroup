// js/utils.js

export function generateUUID() { 
  return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
    (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
  );
}

export function getAllHistoricalData(currentBusinessName) {
    const all = [];
    const prefix = `ipv_data_${currentBusinessName}_`;
    for (const key in localStorage) {
        if (key.startsWith(prefix)) {
            try {
                const date = key.replace(prefix, '');
                all.push({ date, data: JSON.parse(localStorage.getItem(key)) });
            } catch (e) {
                console.error(`Error parseando datos locales para ${key}`, e);
            }
        }
    }
    all.sort((a, b) => new Date(b.date) - new Date(a.date));
    return all;
}

export function getFilteredHistoricalData(startDate, endDate, currentBusinessName) {
    const allData = getAllHistoricalData(currentBusinessName);
    if (!startDate || !endDate) return allData;
    const start = new Date(startDate + 'T00:00:00Z');
    const end = new Date(endDate + 'T23:59:59Z');
    return allData.filter(day => {
        const itemDate = new Date(day.date + 'T12:00:00Z');
        return itemDate >= start && itemDate <= end;
    });
}